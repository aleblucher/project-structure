def world():
    print("Hello!")