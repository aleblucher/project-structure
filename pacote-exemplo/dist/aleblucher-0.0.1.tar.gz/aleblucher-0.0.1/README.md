A guide to project structure.

https://github.com/Insper/dev-aberto