import my_hello

my_hello.world()